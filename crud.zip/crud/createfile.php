<?php

//echo "<pre>"; print_r($detail);


	
	
	
	
	



 ?>
 


<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-switch/3.3.2/css/bootstrap2/bootstrap-switch.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-switch/3.3.2/js/bootstrap-switch.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.validate.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.1/additional-methods.js"></script>
</head>
<body>
<style>
	
	input.error {
		
		border : 1px solid red;
		
	}
	fieldset {
    border: 1px solid black;
    
    border-radius: 5px;
    padding: 10px;
    margin-bottom: 5px;
}



.form-control {

width : auto;


}

label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 700;
    padding-left: 15px;
}

legend {
    display: block;
    width: auto;
    padding: 0;
    margin-bottom: 0px;
    font-size: 21px;
    line-height: inherit;
    color: #333;
    border: 0;
    border-bottom: 1px solid #e5e5e5;
}

.form-group {
    margin: 15px;
}

</style>
<div class="container">
  
  <br><br /><br><br /><br />
  

  
  <div class="" id="accordion">
  <?php
  
  $i=1;
  $scriptvalidation = '';
  $customvalidate ='';
  foreach ($detail as $key => $value) {
  
  //echo "<pre>"; print_r(); exit;
  
     $scriptvalidation.= '
<script type="text/javascript">
$(document).ready(function () {

   
	
$("#'.$key.'create").validate({';
  
  		echo '<form class="form-horizontal" id="'.$key.'create" name="'.$key.'create" action="'.base_url().'welcome/createviews" method="post"  > <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          
           <a data-toggle="collapse" data-parent="#accordion" href="#collapse'.$i.'">Table : '.$key.'</a>
		  


		  
		  
        </h4>
      </div><div id="collapse'.$i.'" class="panel-collapse collapse ">
        <div class="panel-body">
        
        
        <div class="form-group" style=" margin: 15px;">
		<label>Table type</label>
		<br>
		<label>
		<input class="" value="jtable" type="radio"  name="'.$key.'_tabletype" >
		Jquery Datatable
		</label>
		<label>
		<input class="" value="btable" type="radio" name="'.$key.'_tabletype" checked >
		Bootstrap Datatable
		</label>
		</div>
		
		<div class="form-group" style=" margin: 15px;">
		<label>Pagination</label>
		<br>
		<label>
		<input class="" value="spage" type="radio"  name="'.$key.'_tablepage" >
		Server Side
		</label>
		<label>
		<input class="" value="cpage" type="radio" name="'.$key.'_tablepage" checked >
		Client Side
		</label>
		</div>
		
		<div class="form-inline">
        <div class="form-group" style=" margin: 15px;">
		<label>Display Add</label>
		<br>
		<label>
		<input class="" value="yes" type="radio"  name="'.$key.'_dadd" checked >
		Yes
		</label>
		<label>
		<input class="" value="no" type="radio" name="'.$key.'_dadd"  >
		No
		</label>
		</div>
		
        <div class="form-group" style=" margin: 15px;">
		<label>Display Edit</label>
		<br>
		<label>
		<input class="" value="yes" type="radio"  name="'.$key.'_dedit" checked >
		Yes
		</label>
		<label>
		<input class="" value="no" type="radio" name="'.$key.'_dedit"  >
		No
		</label>
		</div>
		
        <div class="form-group" style=" margin: 15px;">
		<label>Display Delete</label>
		<br>
		<label>
		<input class="" value="yes" type="radio"  name="'.$key.'_ddelete" checked >
		Yes
		</label>
		<label>
		<input class="" value="no" type="radio" name="'.$key.'_ddelete"  >
		No
		</label>
		</div>
		
		
		</div>
		
		<div class="form-group" style=" margin: 15px;">
		<label>Add view</label>
		<br>
		<label>
		<input class="" value="new" type="radio" name="'.$key.'_addtype" checked >
		newpage
		</label>
		<label>
		<input class="" value="model" type="radio"  name="'.$key.'_addtype" >
		model
		</label>
		
		</div>
		
		<div class="form-group" style=" margin: 15px;">
		<label>Edit view</label>
		<br>
		<label>
		<input class="" value="new" type="radio" name="'.$key.'_edittype" checked >
		newpage
		</label>
		<label>
		<input class="" value="model" type="radio"  name="'.$key.'_edittype" >
		model
		</label>
		
		</div>
		
		
		
		';
  $validatename = '';
  $validaterules = '';
  $validatemessage = '';
  
  foreach ($value as $k => $v) {
  	
	
	  
	 
	
	if($v['Extra']!='auto_increment')
	{
    	if($v['Field']!='status')
	 	{
	 		 
	 	
	 $validatename.= $v['Field'].'_visible '; 
	 
	 $validaterules.= $v['Field'].'_visible		: { require_from_group: [1, ".send"] },';
	 
	 $validaterules.= 'tablefrom'.$key.$v['Field'].'_type : { selectop'.$key.$v['Field'].' : true },'; 
	 
	 $validaterules.= 'fieldtablefrom'.$key.$v['Field'].'_type : { selectops'.$key.$v['Field'].' : true },';
	 
	 $validaterules.= 'check'.$key.$v['Field'].'_type : { required : true },';
	 
	 $validaterules.= '"manualkey'.$key.$v['Field'].'_type[]" : { required : true },';
	 
	 $validaterules.= '"manualvalue'.$key.$v['Field'].'_type[]" : { required : true },';
		 
	 $validatemessage.= $v['Field'].'_visible	: { require_from_group : "atleast one of these field is required" },';				
	 
	 $validatemessage.= 'tablefrom'.$key.$v['Field'].'_type : { selectop'.$key.$v['Field'].' : "required" },';
	 
	 $validatemessage.= 'check'.$key.$v['Field'].'_type : { required : "required" },';
	 
	 $validatemessage.= 'fieldtablefrom'.$key.$v['Field'].'_type : { selectops'.$key.$v['Field'].' : "required" },';
	 
	 $validatemessage.= '"manualkey'.$key.$v['Field'].'_type[]" : { required : "" },';
	 
	 $validatemessage.= '"manualvalue'.$key.$v['Field'].'_type[]" : { required : "" },';
	 
	 $customvalidate.= '
jQuery.validator.addMethod("selectop'.$key.$v['Field'].'", function(value, element){
    if ($(\'#'.$v['Field'].'_type\').val()==\'select\' && $(\'#tablefrom'.$key.$v['Field'].'_type\').val()==\'\') {
        return false;  
    } else {
        return true;   
    };
}, "requireds");

jQuery.validator.addMethod("selectops'.$key.$v['Field'].'", function(value, element){
    if ($(\'#'.$v['Field'].'_type\').val()==\'select\' && $(\'#fieldtablefrom'.$key.$v['Field'].'_type\').val()==\'\') {
        return false;  
    } else {
        return true;   
    };
}, "requireds");


'; 
	 
     echo '
        
		
		<fieldset>
  <legend>'.$v['Field'].'</legend>
  		
		<div class="form-group">
		<label>
		<input class=" send"  type="checkbox" name="'.$v['Field'].'_visible" >
		visible</label></div>
		<div class="form-group">
		<label>Display Name</label>
		<input class="" type="text" name="'.$v['Field'].'_display" value="'.$v['Field'].'" />
		</div>
		
		
		
		<div class="form-group">
		<label>Validation</label>
		<br>
		
		<label>Required</label>
		<input class="" type="checkbox" name="'.$v['Field'].'_validation[]" value="required" checked>
		
		<label>Email</label>
		<input class="" type="checkbox" name="'.$v['Field'].'_validation[]" value="email" >
		
		<label>Url</label>
		<input class="" type="checkbox" name="'.$v['Field'].'_validation[]" value="url" >
		
		<label>Numeric</label>
		<input class="" type="checkbox" name="'.$v['Field'].'_validation[]" value="num" >
		
		<label>Minlength [10]</label>
		<input class="" type="checkbox" name="'.$v['Field'].'_validation[]" value="minlength" >
		<input class="" style="width: 50px;" type="text" name="'.$v['Field'].'_minlength" value="" >
		
		<label>Maxlength [10]</label>
		<input class="" type="checkbox" name="'.$v['Field'].'_validation[]" value="maxlength" >
		<input class="" style="width: 50px;" type="text" name="'.$v['Field'].'_maxlength" value="" >
		<label>Check Duplicate</label>
		<input class="" type="checkbox" name="'.$v['Field'].'_validation[]" value="remote" >
		
		</div>
		<div class="form-group">
		<label>Type</label>
		<select class="" id="'.$v['Field'].'_type" name="'.$v['Field'].'_type" onchange="selectopt(\''.$key.'\',this.name,this.value);" >
		<option value="textbox" selected>Textbox</option>
		<option value="email" >email</option>
		<option value="url" >url</option>
		<option value="password" >password</option>
		<option value="date" >Date</option>
		<option value="textarea" >textarea</option>
		<option value="editor" >editor</option>
		<option value="checkbox" >checkbox</option>
		<option value="radio" >radio</option>
		<option value="select" >Select</option>
		<option value="multiselect" >Multiselect</option>
		<option value="imageupload" >Image upload</option>
		</select>
		</div>
		<div class="form-group">
		<div id="selectopt'.$key.$v['Field'].'_type" ></div>
		</div>
		<div style="display:none;" id="selectopt'.$key.$v['Field'].'_typefrom" >
		<div class="form-group">
		<label>Table Name</label><select class="" onchange="gettablefield(\''.$key.'\',\''.$v['Field'].'_type\',this.value);" id="tablefrom'.$key.$v['Field'].'_type" name="tablefrom'.$key.$v['Field'].'_type"  ><option value="">----select----</option>'.$tableselect.'</select><br>
		</div>
		
		<div class="form-group">
		<label>Field Name</label><select class="" id="fieldtablefrom'.$key.$v['Field'].'_type" name="fieldtablefrom'.$key.$v['Field'].'_type"  ><option value="">----select----</option></select>
		</div>
		</div>
		
		  </fieldset>
		
		
        ';
		
		}
		
		}
		
	}
  	
	
	$scriptvalidation.= '
	
	
       
	 rules: { 	'.$validaterules.'

			},
	 message: { 	'.$validatemessage.'

			},
	errorPlacement: function(error, element){
				
			if (element.hasClass(\'checkkey\')) {     
					        return true;  
					    }else {                                      
					        error.insertAfter(element);               
					    }
 
        }
				
		}); 
		
		}); 
		
		</script>
		
		
		
		';
    
	 
  
  echo '<input type="submit" class="btn btn-success" name="'.$key.'submit" value="Submit"><input type="hidden" name="table" value="'.$key.'"></form></div>
      

      </div>
      </div>';
  
  $i++;
  
  }
			
	
  
   ?>
    
  
  </div> 
</div>
    <input type="hidden" name="sno" id="sno" value="1" autocomplete="off" />
</body>
</html>

<script>
	
	<?php echo $customvalidate; ?>
	
</script>
	
<?php echo $scriptvalidation; ?>
	

<script>
	
	function gettablefield(table,name,value)
	{
		if(value!='')
		{
			
		
			$.ajax({
		        url  	: "<?php echo base_url().'welcome/gettable'; ?>",
		        type 	: "POST",
		        data 	: {value : value},
		        success	: function (data) {
	     			
	     			
	     			
	     			var html = data;
	     			
	     			html = '<select class="" name="fieldtablefrom'+table+name+'" id="fieldtablefrom'+table+name+'"  ><option value="">----select----</option>';
	     			
	     			html+= data;
	     			
	     			html+= '</select>'
	     			
	     			$('#fieldtablefrom'+table+name).html(html);	
				},
				      
			});
		}
		else
		{
				  	var html = '<select class="" name="fieldtablefrom'+table+name+'" id="fieldtablefrom'+table+name+'"  ><option value="">----select----</option>';
	     			
	     			html+= '</select>'
	     			
	     			$('#fieldtablefrom'+table+name).html(html);	
		}
	
		
		
		
	}
	
	function selectopts(table,name,value)
	{
		if(value=='table')
		{
			
			var optgroup = '<?php echo  $tableselect; ?>';
			
			var html = '<label>Table Name</label><select class="" onchange="gettablefield(\''+table+'\',\''+name+'\',this.value);" type="text" name="tablefrom'+table+name+'" id="tablefrom'+table+name+'"  > <option value="">----select----</option>'+optgroup+'</select><br><label>Field Name</label><select class="" name="fieldtablefrom'+table+name+'" id="fieldtablefrom'+table+name+'"  ><option value="">----select----</option></select>';

			//alert('selectopt'+table+name);
			
			$('#selectopt'+table+name+'from').html(html);
		}
		else
		{
			
			var html='<label>key</label><input type="text" class="checkkey " name="manualkey'+table+name+'[]" id="manualkey'+table+name+'[]" value="" > <label>Value</label><input  type="text" class="checkkey " name="manualvalue'+table+name+'[]" id="manualvalue'+table+name+'[]" value="" ><input type="button" class="btn btn-warning" name="manualadd'+table+name+'[]" id="manualadd'+table+name+'[]" onclick="manualselect(\''+table+'\',\''+name+'\')" value="Add" >';
			
			//alert('selectopt'+table+name);
			
			$('#selectopt'+table+name+'from').html(html);
			
		}
	}
	
	function remove(table,name,value)
	{
		$('#'+table+name+value).remove();
		
		
		
	}
	
	function manualselect(table,name)
	{
		
		
		var sno = $('#sno').val();
		
		var html = '<div id="'+table+name+sno+'"><label>key</label><input class="checkkey " type="text" name="manualkey'+table+name+'[]" id="manualkey'+table+name+'[]" value="" > <label>Value</label><input class="checkkey " type="text" name="manualvalue'+table+name+'[]" id="manualvalue'+table+name+'[]" value="" ><input type="button" class="btn btn-danger" name="manualremove'+table+name+'[]" id="manualremove'+table+name+'[]" onclick="remove(\''+table+'\',\''+name+'\',\''+sno+'\')" value="remove" ></div>'
		
		htmls = $('#selectopt'+table+name+'from').html();
		
		$('#selectopt'+table+name+'from').append(html);
		
		var sno = sno++;
		
		$('#sno').val(sno);
			
	}
	
	function selectopt(table,name,value)
	{
		
		if(value=='select' || value=='multiselect')
		{	
			var html = '<label>From</label><select class="" name="from'+table+name+'" onchange="selectopts(\''+table+'\',\''+name+'\',this.value);" ><option  value="table" selected>Table</option><option  value="manual" >Manual</option></select>';
			
			//alert('selectopt'+table+name);
			
			$('#selectopt'+table+name).html(html);
			
			$('#selectopt'+table+name+'from').css({'display':'block'});
			
			
		}
		else if(value=='checkbox')
		{
			var html = '<label>label=>values</label><textarea name="check'+table+name+'" id="check'+table+name+'" ></textarea>';
			$('#selectopt'+table+name).html(html);
			$('#selectopt'+table+name+'from').css({'display':'none'});
		}
		else if(value=='radio')
		{
			var html = '<label>label=>values</label><textarea name="check'+table+name+'" id="check'+table+name+'" ></textarea>';
			$('#selectopt'+table+name).html(html);
			$('#selectopt'+table+name+'from').css({'display':'none'});
		}
		else if(value=='password')
		{
			var html = '<label>Confirm Password</label><input type="checkbox" name="confirm'+table+name+'" id="confirm'+table+name+'" >';
			$('#selectopt'+table+name).html(html);
			$('#selectopt'+table+name+'from').css({'display':'none'});
		}
		else
		{
			
			//var html='<label>key</label><input class="checkkey " type="text" name="manualkey'+table+name+'[]" id="manualkey'+table+name+'[]" value="" > <label>Value</label><input type="text" class="checkkey " name="manualvalue'+table+name+'[]" id="manualvalue'+table+name+'[]" value="" >';
			
			$('#selectopt'+table+name).html('');
			
			$('#selectopt'+table+name+'from').css({'display':'none'});
		}
	}
	
</script>
	

