<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Common extends CI_Model 
{
	
	function controller($table,$id,$post,$jdata,$bdata,$field,$fieldsposted,$createdarray)
	{
		
		// Controller content
		
		//echo "<pre>"; print_r($post); exit;
		
		if($post)
		{
			
			$fields = $fieldsposted.'status'; 
			
			$function = '';
			
			$createarray = explode(',',$fields);
						
			$create = '';
			$key = 0;
			foreach($createarray as $crt)
			{
				$create.= '\''.$key.'\' => \''.$crt.'\',';
				$key++;
			}
			
			$create = 'array( '.$create.' );';
						
						
			
			$validation='';	
				
			foreach($createdarray as $db)
			{
				// Avoid Auto increment field
				
					// check is display name available
					if($post[$db.'_display'])
					{
						$display = $post[$db.'_display'];
					}
					else 
					{
						$display = $db;
					}
					
					// check is visible
					if($post[$db.'_visible'])
					{
					
						if($post[$db.'_validation'])
						{
							
							$cond='';
							
							foreach($post[$db.'_validation'] as $validate)
							{
								
								if($validate=='required')
								{
									$cond.='required|';
								}
								if($post[$db.'_type']=='password')
								{
									if($post['confirm'.$table.$db.'_type'])
									{
										$conds.='matches['.$db.']';
									}
								}
								
								
								if($validate=='url')
								{
									$cond.='valid_url|';
								}
								if($validate=='email')
								{
									$cond.='valid_email|';
								}
								if($validate=='minlength')
								{
									if($post[$db.'_minlength'] && is_numeric($post[$db.'_minlength']))
									{
										$min = $this->input->post($db.'_minlength');
									}
									else {
										$min = 10;
									}

									$cond.='min_length['.$min.']|';
								}
								if($validate=='maxlength')
								{
									if($post[$db.'_maxlength'] && is_numeric($post[$db.'_maxlength']))
									{
		
										$min = $this->input->post($db.'_maxlength');
									}
									else {
										$min = 10;
									}
									$cond.='max_length['.$min.']|';
								}
								if($validate=='num')
								{
									$cond.='numeric|';
								}
								if($validate=='remote')
								{
									$cond.='callback_'.$table.$db.'|';
									
	$function.= '
public function '.$table.$db.'($option)
{  
  
  $table = \''.$table.'\';
  
  $db = \''.$db.'\';
  
  $id = $this->uri->segment(3);
  
  if($id!=\'\')
  {
  
  	$where = \'\'.$db.\'=\\\'\'.$option.\'\\\' AND status=\\\'Active\\\' AND '.$id.'!=\\\'\'.$id.\'\\\' \';
  }
  else {
		
	$where = \'\'.$db.\'=\\\'\'.$option.\'\\\' AND status=\\\'Active\\\' \';
  }
  
	$num = $this->db->select($db)->from($table)->where($where)->get()->num_rows();
	
	if($num > 0)
	{
		$this->form_validation->set_message(\''.$table.$db.'\', \'The {field} already exists\');
	    
	    return FALSE;
	
	}
	else {
	
		return TRUE;
	
	} 
    
  
}
';	

									
								}
								
								
								
							}
							
							$set = substr($cond,0,-1);
							
							if($this->input->post($db.'_type')=='imageupload')
							{
									
								
								
$validation.= '
if(!isset($_FILES[\''.$db.'\'][\'name\'])) {
	
if(!isset($edit))
{
	
	
$this->form_validation->set_rules(\''.$db.'\', \''.$display.'\', \''.$set.'\');

}

	
}
else
{
	$this->form_validation->set_rules(\''.$db.'\', \''.$db.'\', \'trim\');
}
';
								
							}
							else {
								
								
								if($this->input->post($db.'_type')=='checkbox' || $this->input->post($db.'_type')=='radio' || $this->input->post($db.'_type')=='multiselect')
								{
									$array = '[]';
								}
								else {
									$array = '';
								}
								if(isset($post['confirm'.$table.$db.'_type']))
								{
									$validation.= '$this->form_validation->set_rules(\''.$db.'_cpwd'.$array.'\', \'Confirm Password\', \''.$set.'|'.$conds.'\');
';
									
								}
								
$validation.= '$this->form_validation->set_rules(\''.$db.$array.'\', \''.$display.'\', \''.$set.'\');
';
							}
							
							
			
							
						}
					
					}
					
				
				
			}
			
		}
		
		
				
		//echo $validation; exit;		

		
$controller_content = '
<?php defined(\'BASEPATH\') OR exit(\'No direct script access allowed\');

class '.ucfirst($table).' extends CI_Controller {

 
	public function __construct()
	{
 		parent::__construct();
		
		$this->load->helper(array(\'form\', \'url\'));

        $this->load->library(\'form_validation\');
 	
 	
	}
	
	'.$function.'
	
	
 	public function jgetdata()
	{
		'.$jdata.'
	}
	public function bgetdata()
	{
		'.$bdata.'
	}
 
	public function index()
	{
		
		';
		
		if($this->input->post(''.$table.'_addtype')=='model')
		{
			
		$controller_content.= '
		
		if($this->input->post() || count($_FILES)>0)
		{
			
			$insertdata = array();
			
			$create = '.$create.'
			
			foreach($create as $db)
			{
				
					
					
					
					if($this->input->post($db))
					{
					
					if(is_array($this->input->post($db)))
					{	
						$combine = \'\';
						
						foreach($this->input->post($db) as $checked)
						{
							$combine.=$checked.\',\';
						}
						
						$value = substr($combine,0,-1);

						$insertdata[$db] = $value; 
					}
					else
					{
						$insertdata[$db] = $this->input->post($db);
					}
					}
						
					if(isset($_FILES[$db][\'name\'])) {
						
						$config[\'upload_path\']          = \'upload/\';
		                $config[\'allowed_types\']        = \'gif|jpg|png\';
		                $config[\'max_size\']             = 1000;
		                //$config[\'max_width\']            = 1024;
		                //$config[\'max_height\']           = 768;
		
		                $this->load->library(\'upload\', $config);
		
		                if ( ! $this->upload->do_upload($db))
		                {
		                        $data[$db.\'_error\'] = $this->upload->display_errors();
								
								$data[\'data\'] = $this->db->select(\''.$field.'\')->from(\''.$table.'\')->where(\'status !=\',\'Delete\')->get()->result_array();
								
		                       	$data[\'view\'] = "list";
								
								$this->session->set_flashdata(\'invalid\',\'Invalid attempt\');
								
								redirect("'.$table.'");
		                }
		                else
		                {
		                		$upload_data = $this->upload->data(); 
 		 						
 		 						$file_name =   $upload_data[\'file_name\'];
								
								$file_path = $upload_data[\'full_path\']; // get file path
								
								chmod($file_path,0777);
		                		
		                		$insertdata[$db] = $file_name; 
								
		                }
						
					}
						
						
					//$insertdata[$db] = $this->input->post($db);
				
			}';
			
			if($validation!='')
			{
				
					
				$controller_content.= $validation;
				
				
				
                $controller_content.= 'if ($this->form_validation->run() == TRUE)
                {
                		$insertdata[\'status\'] = \'Active\'; 
                	';
  		
			
				$controller_content.= '$this->db->insert(\''.$table.'\',$insertdata);
				
				$this->session->set_flashdata(\'success\',\'Inserted successfully\');
				
				redirect("'.$table.'");';
			
			                      
                $controller_content.='}
                else
                {
                	$data[\'data\'] = $this->db->select(\''.$field.'\')->from(\''.$table.'\')->where(\'status !=\',\'Delete\')->get()->result_array();
					
					$data[\'view\'] = "list";
					
					$this->session->set_flashdata(\'invalid\',\'Invalid attempt\');
					
					redirect("'.$table.'");
					
				}
				
			}
			else { ';
	
				
			}
		}	
		
		
		$controller_content.= '
			
		$data[\'data\'] = $this->db->select(\''.$field.'\')->from(\''.$table.'\')->where(\'status !=\',\'Delete\')->get()->result_array();
		
		$data[\'view\'] = "list";
		
		$this->load->view(\''.$table.'\',$data);
		';
		
		if($post[''.$table.'_addtype']=='model')
		{
			$controller_content.= '
			}';
		}
		
$controller_content.= '
			
	}
			
	public function add()
	{
		
		if($this->input->post() || count($_FILES)>0)
		{
			
			$insertdata = array();
			
			$create = '.$create.'
			
			foreach($create as $db)
			{
				
					
					
					
					if($this->input->post($db))
					{
					
					if(is_array($this->input->post($db)))
					{	
						$combine = \'\';
						
						foreach($this->input->post($db) as $checked)
						{
							$combine.=$checked.\',\';
						}
						
						$value = substr($combine,0,-1);

						$insertdata[$db] = $value; 
					}
					else
					{
						$insertdata[$db] = $this->input->post($db);
					}
					}
						
					if(isset($_FILES[$db][\'name\'])) {
						
						$config[\'upload_path\']          = \'upload/\';
		                $config[\'allowed_types\']        = \'gif|jpg|png\';
		                $config[\'max_size\']             = 1000;
		                //$config[\'max_width\']            = 1024;
		                //$config[\'max_height\']           = 768;
		
		                $this->load->library(\'upload\', $config);
		
		                if ( ! $this->upload->do_upload($db))
		                {
		                        $data[$db.\'_error\'] = $this->upload->display_errors();
								
		                       	$data[\'view\'] = "add";
		
								$this->load->view("'.$table.'",$data);
		                }
		                else
		                {
		                		$upload_data = $this->upload->data(); 
 		 						
 		 						$file_name =   $upload_data[\'file_name\'];
								
								$file_path = $upload_data[\'full_path\']; // get file path
								
								chmod($file_path,0777);
		                		
		                		$insertdata[$db] = $file_name; 
								
		                }
						
					}
						
						
					//$insertdata[$db] = $this->input->post($db);
				
			}';
			
			if($validation!='')
			{
				
					
				$controller_content.= $validation;
				
				
				
                $controller_content.= 'if ($this->form_validation->run() == TRUE)
                {
                		$insertdata[\'status\'] = \'Active\'; 
                	';
  		
			
				$controller_content.= '$this->db->insert(\''.$table.'\',$insertdata);
				
				$this->session->set_flashdata(\'success\',\'Inserted successfully\');
				
				redirect("'.$table.'");';
			
			                      
                $controller_content.='}
                else
                {
					$data[\'view\'] = "add";
		
					$this->load->view("'.$table.'",$data);
				}';
	
				
			}
		$controller_content.='
		}
		else {
			
			$data[\'view\'] = "add";
		
			$this->load->view("'.$table.'",$data);
				
		}
		
		
	}
	
	public function editajax()
	{
		
		$id = \''.$id.'\';
		
		$edit = $this->input->post(\'id\');
		
		$data = $this->db->select(\''.$field.'\')->from(\''.$table.'\')->where(\''.$id.'\',$edit)->get()->row_array();
		
		$send =\'\';
		
		foreach ($data as $key => $value) {
			
			$send.= $key.\'#\'.$value.\'@\';
			
			
		}
		
		$send = substr($send,0,-1);
		
		echo $send;
		
	}
	
	public function edit($edit)
	{
		
		$id = \''.$id.'\';
		
		
		if($this->input->post() || count($_FILES)>0)
		{
			
			$updatedata = array();
			
			$create = '.$create.'
			
			foreach($create as $db)
			{
				
					
					if(is_array($this->input->post($db)))
					{	
						$combine = \'\';
						
						foreach($this->input->post($db) as $checked)
						{
							$combine.=$checked.\',\';
						}
						
						$value = substr($combine,0,-1);

						$updatedata[$db] = $value;
					}
					else
					{
						$updatedata[$db] = $this->input->post($db);
					}
					
					if(isset($_FILES[$db][\'name\']) && $_FILES[$db][\'name\']!=\'\') {
						
						$config[\'upload_path\']          = \'upload/\';
		                $config[\'allowed_types\']        = \'gif|jpg|png\';
		                $config[\'max_size\']             = 1000;
		                //$config[\'max_width\']            = 1024;
		                //$config[\'max_height\']           = 768;
		
		                $this->load->library(\'upload\', $config);
		
		                if ( ! $this->upload->do_upload($db))
		                {
		                        $data[$db.\'_error\'] = $this->upload->display_errors();
		';						
								
						if($this->input->post(''.$table.'_addtype')=='model')
						{
								
		                    $controller_content.='
		                    
							   	$data[\'view\'] = "list";
								
								$data[\'edit\'] = $this->db->select(\'*\')->from(\''.$table.'\')->where(\''.$id.'\',$edit)->get()->row_array();
								
								$this->session->set_flashdata(\'invalid\',\'Invalid attempt\');
								
								redirect("'.$table.'");
								
						';
						}
						else {
						
								
		                    $controller_content.='
		                    
							   	$data[\'view\'] = "add";
								
								$data[\'edit\'] = $this->db->select(\'*\')->from(\''.$table.'\')->where(\''.$id.'\',$edit)->get()->row_array();
								
								$this->load->view("'.$table.'",$data);
								
						';
						
						}
						
						$controller_content.='
						
		                }
		                else
		                {
		                		$upload_data = $this->upload->data(); 
 		 						
 		 						$file_name =   $upload_data[\'file_name\'];
		                		
		                		$updatedata[$db] = $file_name; 
								
								$file_path = $upload_data[\'full_path\']; // get file path
								
								chmod($file_path,0777);
								
								$dbfile = $this->db->select(\'*\')->from(\''.$table.'\')->where(\''.$id.'\',$edit)->get()->row_array()[\'\'.$db.\'\'];
								
								if(file_exists(\'upload/\'.$dbfile.\'\'))
								{
								 	unlink(\'upload/\'.$dbfile.\'\');
								}
								
								
		                }
						
					}
					else if(isset($_FILES[$db][\'name\']) && $_FILES[$db][\'name\']==\'\') {
						unset($updatedata[$db]);
					}
					
					
					
				
			}';
			
			if($validation!='')
			{
				
				
				
				
				
					
				$controller_content.= $validation;
				
				
				
                $controller_content.= 'if ($this->form_validation->run() == TRUE)
                {
                		unset($updatedata[\'status\']);
                		//$insertdata[\'status\'] = \'Active\';
                ';
  		
			
				$controller_content.= '$this->db->where("'.$id.'",$edit);			
			$this->db->update("'.$table.'",$updatedata);
			
			$this->session->set_flashdata(\'success\',\'Updated successfully\');
			
			redirect("'.$table.'");	';
			
			                      
                $controller_content.='}
                else
                {
                	
					';						
								
						if($this->input->post(''.$table.'_addtype')=='model')
						{
								
		                    $controller_content.='
		                    
							   	$data[\'view\'] = "list";
								
								$data[\'edit\'] = $this->db->select(\'*\')->from(\''.$table.'\')->where(\''.$id.'\',$edit)->get()->row_array();
								
								$this->session->set_flashdata(\'invalid\',\'Invalid attempt\');
								
								redirect("'.$table.'");
								
						';
						}
						else {
						
								
		                    $controller_content.='
		                    
							   	$data[\'view\'] = "add";
								
								$data[\'edit\'] = $this->db->select(\'*\')->from(\''.$table.'\')->where(\''.$id.'\',$edit)->get()->row_array();
								
								
								
								$this->load->view("'.$table.'",$data);
								
						';
						
						}
						
						$controller_content.='
						
					
				}';
	
				
			}
		$controller_content.='
		}
		else {
			
		$data[\'edit\'] = $this->db->select(\''.$field.'\')->from(\''.$table.'\')->where(\''.$id.'\',$edit)->get()->row_array();
		
		$data[\'view\'] = "add";
		
		$this->load->view("'.$table.'",$data);
				
		
			
				
			
		}
		
		
		
		
	}

	/*
	public function delete()
		{
			
			$id = $this->db->query("SHOW COLUMNS FROM '.$table.' where extra like \'%auto_increment%\'")->row_array()[\'Field\'];
			
			if($this->input->post())
			{
				
				
				
				$delete = $this->input->post(\'id\');
				
				foreach($this->db->query("SHOW COLUMNS FROM '.$table.'")->result_array() as $fieldname => $db)
				{
					// Avoid Auto increment field
					
					if($db[\'Extra\']!=\'auto_increment\')
					{
						
						$dbfile = $this->db->select(\'*\')->from(\''.$table.'\')->where(\''.$id.'\',$delete)->get()->row_array()[\'\'.$db[\'Field\'].\'\'];
									
						if(file_exists(\'upload/\'.$dbfile.\'\'))
						{
							 unlink(\'upload/\'.$dbfile.\'\');
						}
						
					}
				}
				
				
				$this->db->where("'.$id.'",$delete);			
				$this->db->delete("'.$table.'");
			}
			
		}*/
	
	
	
		/*
		public function deleteall()
				{
				
				$id = $this->db->query("SHOW COLUMNS FROM '.$table.' where extra like \'%auto_increment%\'")->row_array()[\'Field\'];
				
				if($this->input->post())
				{
					
					
					
					$delete = $this->input->post(\'ids\');
					
					$explode = explode(",",$delete); 
					
					foreach($explode as $ids)
					{
						
						
						
					
					foreach($this->db->query("SHOW COLUMNS FROM '.$table.'")->result_array() as $fieldname => $db)
					{
						// Avoid Auto increment field
						
						if($db[\'Extra\']!=\'auto_increment\')
						{
							
							$dbfile = $this->db->select(\'*\')->from(\''.$table.'\')->where(\''.$id.'\',$ids)->get()->row_array()[\'\'.$db[\'Field\'].\'\'];
										
							if(file_exists(\'upload/\'.$dbfile.\'\'))
							{
								 unlink(\'upload/\'.$dbfile.\'\');
							}
							
						}
					}
					
					
					$this->db->where("'.$id.'",$ids);			
					$this->db->delete("'.$table.'");
					
					}
					
				}
				
			}*/
		


	
	public function statuschange()
	{
		
		if($this->input->post())
		{
			
			$id = $this->input->post(\'id\');
			
			$status = $this->input->post(\'status\');
			
			$data = array( \'status\' => $status );
			
			$this->db->where("'.$id.'",$id);			
			
			$this->db->update("'.$table.'",$data);
			
			
		}
		
	}
			
			
	public function statuschangeall()
	{
			
		$id = \''.$id.'\';
		
		if($this->input->post())
		{
			$delete = $this->input->post(\'ids\');
			
			$status = $this->input->post(\'status\');
			
			$explode = explode(",",$delete); 
			
			$data = array( \'status\' => $status );
			
			
			foreach($explode as $ids)
			{
				
			
			$this->db->where("'.$id.'",$ids);			
			
			$this->db->update("'.$table.'",$data);
			
			}
			
		}
		
		
		
	}
	
	
	
		
}
		
?>';
	
	return $controller_content;
	
		
	}
}


